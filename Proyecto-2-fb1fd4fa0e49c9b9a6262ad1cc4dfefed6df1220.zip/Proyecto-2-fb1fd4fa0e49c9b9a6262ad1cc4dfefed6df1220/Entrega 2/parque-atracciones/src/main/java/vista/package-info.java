/**
 * Package information for the vista module.
 */
package vista;
