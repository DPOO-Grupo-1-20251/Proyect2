/**
 * Paquete principal para las clases de la capa de Aplicación.
 * Contiene los servicios y casos de uso del sistema.
 */
package aplicacion;
