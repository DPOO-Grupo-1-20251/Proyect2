/**
 * Paquete para las clases relacionadas con la venta e inventario de tiquetes.
 * Incluye categorías, modalidades y gestión de inventario.
 */
package dominio.tiquete;
