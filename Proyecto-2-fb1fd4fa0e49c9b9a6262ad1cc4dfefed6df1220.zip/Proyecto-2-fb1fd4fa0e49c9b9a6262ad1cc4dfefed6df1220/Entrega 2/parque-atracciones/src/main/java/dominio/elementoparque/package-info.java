/**
 * Paquete para las clases relacionadas con las atracciones del parque.
 * Incluye tipos de atracciones, características y restricciones.
 */
package dominio.elementoparque;
