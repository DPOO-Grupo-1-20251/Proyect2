/**
 * Paquete para las clases relacionadas con los usuarios del sistema.
 * Incluye autenticación, autorización y perfiles de usuario.
 */
package dominio.usuario;
