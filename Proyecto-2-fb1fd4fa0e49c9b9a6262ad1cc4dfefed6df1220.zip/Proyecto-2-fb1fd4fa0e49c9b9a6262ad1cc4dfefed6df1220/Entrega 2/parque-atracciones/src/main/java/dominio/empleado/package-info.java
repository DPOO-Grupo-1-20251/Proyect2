/**
 * Paquete para las clases relacionadas con los empleados del parque.
 * Incluye roles, capacitaciones y asignaciones.
 */
package dominio.empleado;
