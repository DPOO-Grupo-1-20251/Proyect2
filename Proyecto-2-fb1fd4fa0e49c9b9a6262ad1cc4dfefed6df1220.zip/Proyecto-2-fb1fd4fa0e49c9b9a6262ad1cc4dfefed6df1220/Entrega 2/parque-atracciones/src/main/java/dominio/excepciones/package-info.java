/**
 * Paquete que contiene las excepciones personalizadas de la aplicación,
 * representando errores específicos del dominio del negocio.
 */
package dominio.excepciones;
