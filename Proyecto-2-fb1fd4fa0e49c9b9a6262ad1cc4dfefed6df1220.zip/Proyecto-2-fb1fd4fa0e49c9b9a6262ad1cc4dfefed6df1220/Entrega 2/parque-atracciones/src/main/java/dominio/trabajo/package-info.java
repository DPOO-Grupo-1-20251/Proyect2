/**
 * Paquete para las clases relacionadas con las tareas y trabajos en el parque.
 * Incluye asignación de tareas y seguimiento de progreso.
 */
package dominio.trabajo;
