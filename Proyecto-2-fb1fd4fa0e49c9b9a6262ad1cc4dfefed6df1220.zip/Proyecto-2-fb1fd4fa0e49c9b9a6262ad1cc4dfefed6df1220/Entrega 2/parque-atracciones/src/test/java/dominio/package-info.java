/**
 * Paquete para las clases de prueba relacionadas con el dominio del negocio.
 * (Este archivo se crea para resolver una advertencia de Maven).
 */
package dominio;
